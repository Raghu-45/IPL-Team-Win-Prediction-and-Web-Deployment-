from django.db import models

import tensorflow as tf

MODEL_PATH = 'C:\\Users\\admin\\OneDrive\\Desktop\\ML projects\\Models\\Bell Pepper Bacteria - CNN.h5'
model = tf.keras.models.load_model(MODEL_PATH)
