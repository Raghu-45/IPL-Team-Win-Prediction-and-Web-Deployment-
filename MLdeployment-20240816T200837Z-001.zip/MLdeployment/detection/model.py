import tensorflow as tf

MODEL_PATH = 'path/to/your/model.h5'
model = tf.keras.models.load_model(MODEL_PATH)
