from django.shortcuts import render
from .forms import ImageUploadForm
from .model import model
from tensorflow.keras.preprocessing import image
import numpy as np

def predict_image(request):
    if request.method == 'POST':
        form = ImageUploadForm(request.POST, request.FILES)
        if form.is_valid():
            img = form.cleaned_data['image']
            img_path = f'media/{img.name}'
            with open(img_path, 'wb+') as destination:
                for chunk in img.chunks():
                    destination.write(chunk)
            
            img = image.load_img(img_path, target_size=(224, 224))
            img_array = image.img_to_array(img)
            img_array = np.expand_dims(img_array, axis=0) / 255.0

            prediction = model.predict(img_array)
            result = 'Infected' if prediction[0][0] > 0.5 else 'Healthy'

            return render(request, 'detection/result.html', {'result': result})
    else:
        form = ImageUploadForm()
    return render(request, 'detection/upload.html', {'form': form})
