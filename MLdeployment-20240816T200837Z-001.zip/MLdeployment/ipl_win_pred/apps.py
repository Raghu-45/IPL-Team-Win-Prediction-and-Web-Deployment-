from django.apps import AppConfig


class IplWinPredConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ipl_win_pred'
